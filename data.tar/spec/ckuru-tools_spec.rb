# $Id$

require File.join(File.dirname(__FILE__), %w[spec_helper])

describe CkuruTools do
end

# EOF
